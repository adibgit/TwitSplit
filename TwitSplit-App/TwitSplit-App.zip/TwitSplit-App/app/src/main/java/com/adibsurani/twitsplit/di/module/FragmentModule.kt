package com.adibsurani.twitsplit.di.module

import com.adibsurani.twitsplit.data.api.ApiServiceInterface
import com.adibsurani.twitsplit.view.contract.TweetContract
import com.adibsurani.twitsplit.view.presenter.TweetPresenter
import dagger.Module
import dagger.Provides

/**
 * Created by ogulcan on 07/02/2018.
 */
@Module
class FragmentModule {

    /*provide presenter here*/
    @Provides
    fun provideTweetPresenter(): TweetContract.Presenter {
        return TweetPresenter()
    }

    @Provides
    fun provideAboutPresenter(): TweetContract.Presenter {
        return TweetPresenter()
    }


    /*---------------------*/


    /*provide services here*/
    @Provides
    fun provideApiService(): ApiServiceInterface {
        return ApiServiceInterface.create()
    }
}