package com.adibsurani.twitsplit.helper

class Constants {

    companion object {
        const val BASE_URL = "PLACE_BASE_URL"
    }

}