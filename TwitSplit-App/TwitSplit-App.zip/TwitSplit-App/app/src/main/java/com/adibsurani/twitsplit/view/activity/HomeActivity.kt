package com.adibsurani.twitsplit.view.activity

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.adibsurani.twitsplit.R

class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
