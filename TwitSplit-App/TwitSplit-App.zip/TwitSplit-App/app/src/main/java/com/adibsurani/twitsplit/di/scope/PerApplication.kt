package com.ogulcan.android.mvp.app.di.scope

import javax.inject.Qualifier

/**
 * Created by ogulcan on 07/02/2018.
 */
@Qualifier
@Retention(AnnotationRetention.RUNTIME)
annotation class PerApplication