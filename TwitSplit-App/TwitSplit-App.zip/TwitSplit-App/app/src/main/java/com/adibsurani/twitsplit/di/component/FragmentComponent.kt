package com.ogulcan.android.mvp.app.di.component

import com.ogulcan.android.mvp.app.di.module.FragmentModule
import dagger.Component

/**
 * Created by ogulcan on 07/02/2018.
 */
@Component(modules = arrayOf(FragmentModule::class))
interface FragmentComponent {





}
