package com.adibsurani.twitsplit.view.activity

class SplashActivity {
}