package com.adibsurani.twitsplit.view.fragment

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.adibsurani.twitsplit.R
import com.adibsurani.twitsplit.view.contract.TweetContract
import com.adibsurani.twitsplit.view.presenter.TweetPresenter
import javax.inject.Inject

class TweetFragment:
    Fragment(),
    TweetContract.View {

    @Inject
    lateinit var tweetPresenter: TweetContract.Presenter
    private lateinit var rootView: View

    fun newInstance(): TweetFragment {
        return TweetFragment()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        injectDependency()
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        rootView = inflater!!.inflate(R.layout.fragment_tweet, container, false)
        return rootView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        tweetPresenter.attach(this)
        tweetPresenter.subscribe()
        initView()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        tweetPresenter.unsubscribe()
    }

    override fun showTweetLoad(show: Boolean) {

    }







}