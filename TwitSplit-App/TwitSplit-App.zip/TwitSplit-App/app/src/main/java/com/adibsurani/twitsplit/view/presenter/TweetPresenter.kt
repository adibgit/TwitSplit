package com.adibsurani.twitsplit.view.presenter

import com.adibsurani.twitsplit.view.contract.TweetContract

class TweetPresenter : TweetContract.Presenter {

    override fun subscribe() {

    }

    override fun unsubscribe() {

    }

    override fun attach(view: TweetContract.View) {

    }

    override fun postTweet(tweets: List<String>) {

    }


}